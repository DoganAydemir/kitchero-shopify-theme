/**
 * Collection Filters — Section Rendering API for AJAX filtering
 * Updates product grid without full page reload.
 * Falls back to URL navigation when JS disabled (noscript button).
 */
(function () {
  'use strict';

  function init() {
    var forms = document.querySelectorAll('[data-collection-filters-form]');
    if (forms.length === 0) return;

    /* Checkbox change → AJAX filter update */
    document.querySelectorAll('[data-filter-checkbox]').forEach(function (checkbox) {
      checkbox.addEventListener('change', function () {
        applyFilters();
      });
    });

    /* Price input → debounced AJAX */
    var priceTimer;
    document.querySelectorAll('[data-filter-price]').forEach(function (input) {
      input.addEventListener('input', function () {
        clearTimeout(priceTimer);
        priceTimer = setTimeout(function () {
          applyFilters();
        }, 800);
      });
    });
  }

  function buildFilterUrl() {
    var params = new URLSearchParams();

    /* Collect all checked checkboxes */
    document.querySelectorAll('[data-filter-checkbox]:checked').forEach(function (cb) {
      params.append(cb.name, cb.value);
    });

    /* Collect price inputs */
    document.querySelectorAll('[data-filter-price]').forEach(function (input) {
      if (input.value) {
        params.append(input.name, input.value);
      }
    });

    /* Preserve sort_by */
    var currentUrl = new URL(window.location.href);
    var sortBy = currentUrl.searchParams.get('sort_by');
    if (sortBy) params.set('sort_by', sortBy);

    return window.location.pathname + '?' + params.toString();
  }

  function applyFilters() {
    var newUrl = buildFilterUrl();

    /* Find the section ID for Section Rendering API */
    var sectionEl = document.querySelector('[data-section-type="main-collection"]');
    if (!sectionEl) {
      /* Fallback: full page navigation */
      window.location.href = newUrl;
      return;
    }

    var sectionId = sectionEl.closest('.shopify-section')
      ? sectionEl.closest('.shopify-section').id.replace('shopify-section-', '')
      : null;

    if (!sectionId) {
      window.location.href = newUrl;
      return;
    }

    /* Fetch new section HTML via Section Rendering API */
    var fetchUrl = newUrl + (newUrl.includes('?') ? '&' : '?') + 'section_id=' + sectionId;

    fetch(fetchUrl)
      .then(function (response) {
        if (!response.ok) throw new Error('Filter fetch failed');
        return response.text();
      })
      .then(function (html) {
        /* Parse response and replace grid + controls */
        var parser = new DOMParser();
        var doc = parser.parseFromString(html, 'text/html');

        /* Replace product grid */
        var newGrid = doc.getElementById('product-grid');
        var oldGrid = document.getElementById('product-grid');
        if (newGrid && oldGrid) {
          oldGrid.innerHTML = newGrid.innerHTML;
        }

        /* Replace active filters */
        var newFilters = doc.querySelector('.kt-collection__active-filters');
        var oldFilters = document.querySelector('.kt-collection__active-filters');
        var controlsContainer = document.querySelector('[data-collection-controls] .page-width');

        if (newFilters && oldFilters) {
          oldFilters.outerHTML = newFilters.outerHTML;
        } else if (newFilters && controlsContainer) {
          controlsContainer.insertAdjacentHTML('beforeend', newFilters.outerHTML);
        } else if (!newFilters && oldFilters) {
          oldFilters.remove();
        }

        /* Replace results count */
        var newCount = doc.querySelector('.kt-collection__results-count');
        var oldCount = document.querySelector('.kt-collection__results-count');
        if (newCount && oldCount) {
          oldCount.textContent = newCount.textContent;
        }

        /* Replace pagination */
        var newPagination = doc.querySelector('.kt-collection__pagination');
        var oldPagination = document.querySelector('.kt-collection__pagination');
        if (newPagination && oldPagination) {
          oldPagination.innerHTML = newPagination.innerHTML;
        } else if (!newPagination && oldPagination) {
          oldPagination.remove();
        }

        /* Update URL without reload */
        window.history.pushState({}, '', newUrl);

        /* Re-init countdowns if present */
        if (typeof initAll === 'function') initAll();

        /* Publish event for other scripts */
        if (typeof publish === 'function') {
          publish('collection:filtered', { url: newUrl });
        }
      })
      .catch(function () {
        /* Fallback on error */
        window.location.href = newUrl;
      });
  }

  init();

  /* Re-init after section reload in editor */
  document.addEventListener('shopify:section:load', init);

  /* Handle browser back/forward */
  window.addEventListener('popstate', function () {
    window.location.reload();
  });
})();
